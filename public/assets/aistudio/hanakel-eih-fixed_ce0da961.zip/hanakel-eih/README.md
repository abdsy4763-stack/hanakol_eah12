# هناكل إيه؟ — مساعد الطهي الذكي

## الهيكل
- `public/index.html` + `public/app.js` : الواجهة (5 تبويبات، تُحفظ البيانات في المتصفح)
- `netlify/functions/recipes.js` : الدالة التي تتصل بـ Gemini (المفتاح سري على الخادم)
- `netlify.toml` : إعدادات النشر

## النشر على Netlify
1. ارفع المجلد إلى GitHub واربطه بـ Netlify (أو استخدم `netlify deploy --prod` من Netlify CLI).
   > الرفع بالسحب والإفلات لا يبني الدوال دائماً؛ استخدم GitHub أو CLI.
2. Site settings → Environment variables:
   - `GEMINI_API_KEY` = مفتاحك من Google AI Studio (مطلوب)
   - `GEMINI_MODEL` = اختياري. الافتراضي `gemini-2.5-flash` مع بديل تلقائي `gemini-3.6-flash`.
3. أعد النشر.

## التشغيل المحلي
`npx netlify-cli dev` ثم افتح http://localhost:8888

## الاختبار
`npm run test:fn`
