'use strict';
/* هناكل إيه؟ — منطق الواجهة. كل البيانات تُحفظ في localStorage على جهاز المستخدم. */

const API_URL = '/.netlify/functions/recipes';
const DAYS = ['السبت', 'الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'];
const MEALS = ['فطور', 'غداء', 'عشاء', 'تحلاية'];
const DEFAULT_PANTRY = ['ملح', 'فلفل أسود', 'زيت', 'سكر', 'رز', 'طحين', 'بهارات', 'ماء'];

/* ---------- أدوات ---------- */
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const norm = (s) => String(s ?? '').toLowerCase()
  .replace(/[ً-ْـ]/g, '').replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي').replace(/\s+/g, ' ').trim();
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const hash = (s) => { let h = 5381; for (const c of s) h = ((h << 5) + h + c.charCodeAt(0)) | 0; return (h >>> 0).toString(36); };
const toWestern = (s) => String(s).replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));

const store = {
  get(k, def) { try { const v = localStorage.getItem('hk_' + k); return v ? JSON.parse(v) : def; } catch { return def; } },
  set(k, v) { try { localStorage.setItem('hk_' + k, JSON.stringify(v)); } catch { /* التخزين غير متاح */ } },
};

/* ---------- الحالة ---------- */
const state = {
  ingredients: store.get('ingredients', []),
  pantry: store.get('pantry', DEFAULT_PANTRY),
  favorites: store.get('favorites', []),
  plan: store.get('plan', {}),
  shopping: store.get('shopping', []),
  mealType: store.get('mealType', 'غداء'),
  results: new Map(),
  loading: false,
};
const save = (k) => store.set(k, state[k]);

let toastTimer;
function toast(msg) {
  const t = $('toast'); t.textContent = msg; t.style.opacity = '1';
  clearTimeout(toastTimer); toastTimer = setTimeout(() => { t.style.opacity = '0'; }, 2200);
}

/* ---------- التبويبات ---------- */
function switchTab(name) {
  document.querySelectorAll('.tab-content').forEach((el) => el.classList.toggle('active', el.id === 'tab-' + name));
  document.querySelectorAll('.tab-btn').forEach((b) => {
    const on = b.dataset.tab === name;
    b.classList.toggle('bg-primary', on); b.classList.toggle('text-white', on); b.classList.toggle('shadow', on);
    b.classList.toggle('text-gray-600', !on);
    b.setAttribute('aria-current', on ? 'page' : 'false');
  });
  if (name === 'planner') renderPlanner();
  if (name === 'favorites') renderFavorites();
  if (name === 'shopping') renderShopping();
  window.scrollTo({ top: 0 });
}

/* ---------- قوائم الوسوم (مكونات / مخزن) ---------- */
function addUnique(list, raw) {
  const v = String(raw).replace(/\s+/g, ' ').trim().slice(0, 40);
  if (!v) return false;
  if (list.some((x) => norm(x) === norm(v))) return false;
  list.push(v); return true;
}
function chips(list, action, cls) {
  return list.map((x, i) => `<span class="chip-enter ${cls} px-3 py-1.5 rounded-full text-sm font-semibold flex items-center gap-2">${esc(x)}
    <button data-action="${action}" data-i="${i}" class="opacity-60 hover:opacity-100" aria-label="حذف ${esc(x)}">✕</button></span>`).join('');
}
function renderIngredients() {
  $('ingredients-tags').innerHTML = state.ingredients.length
    ? chips(state.ingredients, 'del-ingredient', 'bg-orange-100 text-orange-800 border border-orange-200')
    : '<span class="text-gray-400 text-sm self-center">أضف مكوناتك أعلاه للبدء...</span>';
}
function renderPantry() {
  $('pantry-list').innerHTML = state.pantry.length
    ? chips(state.pantry, 'del-pantry', 'bg-green-100 text-green-800 border border-green-200')
    : '<span class="text-gray-400 text-sm self-center">المخزن فارغ.</span>';
}
function setMealType(m) {
  state.mealType = m; store.set('mealType', m);
  document.querySelectorAll('.meal-btn').forEach((b) => {
    const on = b.dataset.meal === m;
    b.className = 'meal-btn py-2 px-1 rounded-xl font-bold text-xs border ' +
      (on ? 'border-primary bg-primary text-white shadow' : 'border-gray-200 bg-gray-50 hover:bg-orange-50');
    b.setAttribute('aria-pressed', on);
  });
}

/* ---------- مطابقة المكونات ---------- */
const haveSet = (extra = []) => [...state.pantry, ...extra].map(norm).filter((x) => x.length >= 2);
function isHave(ing, have) { const n = norm(ing); return have.some((h) => n.includes(h) || (n.length >= 3 && h.includes(n))); }
function missingOf(recipe, includeCurrent = true) {
  const have = haveSet(includeCurrent ? state.ingredients : []);
  return recipe.ingredients.filter((i) => !isHave(i, have));
}

/* ---------- بطاقة الوصفة ---------- */
const recipeId = (r) => 'r' + hash(norm(r.name) + '|' + norm(r.ingredients.slice(0, 3).join()));
const isFav = (id) => state.favorites.some((f) => f.id === id);

function parseMinutes(step) {
  const s = toWestern(step);
  if (/نصف\s*ساع/.test(s)) return 30;
  if (/دقيقتين|دقيقتان/.test(s)) return 2;
  if (/ساعتين|ساعتان/.test(s)) return 120;
  const m = s.match(/(\d+(?:[.,]\d+)?)\s*(?:-|إلى|الى|–)?\s*(?:\d+\s*)?(دقيق|دقائق|ساع)/);
  if (!m) return 0;
  const n = parseFloat(m[1].replace(',', '.'));
  const mins = m[2].startsWith('ساع') ? n * 60 : n;
  return mins > 0 && mins <= 600 ? Math.round(mins) : 0;
}

function recipeCard(r) {
  const have = haveSet(state.ingredients);
  const miss = r.ingredients.filter((i) => !isHave(i, have)).length;
  const fav = isFav(r.id);
  const ings = r.ingredients.map((i) => {
    const ok = isHave(i, have);
    return `<li class="flex items-center gap-2 text-sm ${ok ? 'text-gray-700' : 'text-red-600 font-semibold'}">
      <span>${ok ? '✅' : '🛒'}</span><span>${esc(i)}</span></li>`;
  }).join('');
  const steps = r.steps.map((s, i) => {
    const mins = parseMinutes(s);
    return `<li class="flex gap-3 items-start"><span class="bg-primary text-white w-6 h-6 rounded-full text-xs flex items-center justify-center shrink-0 mt-0.5">${i + 1}</span>
      <div class="flex-grow text-sm leading-7">${esc(s)}
      ${mins ? `<button data-action="timer" data-min="${mins}" class="no-print mr-2 text-xs bg-orange-50 text-primary border border-orange-200 rounded-lg px-2 py-0.5 font-bold">⏱ ${mins} د</button>` : ''}
      </div></li>`;
  }).join('');
  return `<article class="bg-white rounded-3xl shadow-xl border border-orange-100 overflow-hidden" data-id="${esc(r.id)}">
    <div class="bg-gradient-to-l from-orange-50 to-white p-5 flex items-start justify-between gap-3">
      <div>
        <h3 class="text-xl font-black text-gray-800">${esc(r.name)}</h3>
        <div class="flex flex-wrap gap-2 mt-2 text-xs font-bold">
          ${r.cuisine ? `<span class="bg-white border border-orange-200 text-orange-700 px-2 py-1 rounded-lg">🌐 ${esc(r.cuisine)}</span>` : ''}
          ${r.meal ? `<span class="bg-white border border-gray-200 text-gray-600 px-2 py-1 rounded-lg">🍽️ ${esc(r.meal)}</span>` : ''}
          ${r.time ? `<span class="bg-white border border-gray-200 text-gray-600 px-2 py-1 rounded-lg">⏱ ${esc(r.time)}</span>` : ''}
          <span class="px-2 py-1 rounded-lg ${miss ? 'bg-red-50 text-red-600 border border-red-200' : 'bg-green-50 text-green-700 border border-green-200'}">${miss ? `ينقصك ${miss}` : 'كل المكونات متوفرة'}</span>
        </div>
      </div>
      <button data-action="fav" data-id="${esc(r.id)}" class="no-print text-2xl ${fav ? 'text-red-500' : 'text-gray-300 hover:text-red-400'}" aria-label="${fav ? 'إزالة من المفضلة' : 'إضافة للمفضلة'}" aria-pressed="${fav}">♥</button>
    </div>
    <div class="p-5 grid md:grid-cols-5 gap-6">
      <div class="md:col-span-2"><h4 class="font-bold mb-2">المكونات</h4><ul class="space-y-1.5">${ings}</ul>
        ${miss ? `<button data-action="shop-missing" data-id="${esc(r.id)}" class="no-print mt-3 w-full text-sm bg-orange-50 text-primary border border-orange-200 rounded-xl py-2 font-bold">🛒 أضف الناقص للقائمة</button>` : ''}</div>
      <div class="md:col-span-3"><h4 class="font-bold mb-2">طريقة التحضير</h4><ol class="space-y-3">${steps}</ol></div>
    </div></article>`;
}
const findRecipe = (id) => state.results.get(id) || state.favorites.find((f) => f.id === id);

/* ---------- البحث عبر الذكاء الاصطناعي ---------- */
function loadingHtml() {
  return [1, 2, 3].map(() => `<div class="bg-white rounded-3xl shadow p-6 animate-pulse space-y-3"><div class="h-5 bg-gray-200 rounded w-1/3"></div><div class="h-3 bg-gray-100 rounded w-2/3"></div><div class="h-3 bg-gray-100 rounded w-1/2"></div></div>`).join('');
}
function errorHtml(msg) {
  return `<div class="bg-red-50 border border-red-200 text-red-700 rounded-2xl p-4 text-sm font-semibold flex items-center justify-between gap-3">
    <span>⚠️ ${esc(msg)}</span><button data-action="retry" class="bg-white border border-red-200 rounded-xl px-3 py-1.5 text-xs">إعادة المحاولة</button></div>`;
}

async function fetchOnlineRecipes() {
  if (state.loading) return;
  const list = [...state.ingredients];
  if ($('include-pantry').checked) state.pantry.forEach((p) => addUnique(list, p));
  if (!state.ingredients.length) { toast('أضف مكوناً واحداً على الأقل'); $('ingredient-input').focus(); return; }

  const btn = $('generate-btn'), out = $('recipes-results');
  state.loading = true; btn.disabled = true; btn.querySelector('span').textContent = 'جاري البحث...';
  out.innerHTML = loadingHtml();
  try {
    const res = await fetch(API_URL, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ingredients: list, mealType: state.mealType, cuisine: $('cuisine-select').value, diet: $('dietary-select').value }),
    });
    let data = null;
    try { data = await res.json(); } catch { /* ليس JSON */ }
    if (!res.ok) throw new Error(data?.error || (res.status === 404 ? 'الخدمة غير متاحة. تأكد من نشر المشروع على Netlify.' : 'حدث خطأ غير متوقع.'));
    if (!Array.isArray(data) || !data.length) throw new Error('لم نحصل على وصفات، أعد المحاولة.');
    state.results = new Map();
    data.forEach((r) => { r.id = recipeId(r); state.results.set(r.id, r); });
    out.innerHTML = data.map(recipeCard).join('');
    out.scrollIntoView({ behavior: 'smooth', block: 'start' });
  } catch (e) {
    out.innerHTML = errorHtml(e.name === 'TypeError' ? 'تعذّر الاتصال بالإنترنت أو بالخادم.' : e.message);
  } finally {
    state.loading = false; btn.disabled = false; btn.querySelector('span').textContent = 'ابحث أونلاين واقترح وجبات شهية الآن!';
  }
}

/* ---------- المفضلة ---------- */
function toggleFav(id) {
  const i = state.favorites.findIndex((f) => f.id === id);
  if (i >= 0) {
    state.favorites.splice(i, 1);
    for (const d of Object.keys(state.plan)) for (const m of Object.keys(state.plan[d] || {})) if (state.plan[d][m] === id) delete state.plan[d][m];
    save('plan'); toast('أُزيلت من المفضلة');
  } else {
    const r = findRecipe(id); if (!r) return;
    state.favorites.unshift({ ...r }); toast('أُضيفت للمفضلة ❤️');
  }
  save('favorites');
  const on = isFav(id);
  document.querySelectorAll(`[data-action="fav"]`).forEach((b) => {
    if (b.dataset.id !== id) return;
    b.className = 'no-print text-2xl ' + (on ? 'text-red-500' : 'text-gray-300 hover:text-red-400');
    b.setAttribute('aria-pressed', on);
  });
  if ($('tab-favorites').classList.contains('active')) renderFavorites();
}
function refreshCards() {
  const out = $('recipes-results');
  if (state.results.size) out.innerHTML = [...state.results.values()].map(recipeCard).join('');
}
function renderFavorites() {
  $('fav-count').textContent = state.favorites.length ? `${state.favorites.length} وصفة` : '';
  $('favorites-list').innerHTML = state.favorites.length
    ? state.favorites.map(recipeCard).join('')
    : `<div class="bg-white rounded-3xl p-10 text-center text-gray-400 shadow">لا توجد وصفات مفضلة بعد. اضغط على ❤️ في أي وصفة لحفظها هنا.</div>`;
}

/* ---------- قائمة الناقص ---------- */
function addShopping(names) {
  let n = 0;
  names.forEach((name) => {
    const v = String(name).trim().slice(0, 80); if (!v) return;
    if (state.shopping.some((s) => norm(s.name) === norm(v))) return;
    state.shopping.push({ id: uid(), name: v, done: false }); n++;
  });
  save('shopping'); updateBadge();
  if ($('tab-shopping').classList.contains('active')) renderShopping();
  return n;
}
function updateBadge() {
  const n = state.shopping.filter((s) => !s.done).length, b = $('shopping-badge');
  b.textContent = n > 99 ? '99+' : n; b.classList.toggle('hidden', n === 0);
}
function renderShopping() {
  $('shopping-list').innerHTML = state.shopping.length
    ? state.shopping.map((s) => `<li class="flex items-center gap-3 bg-gray-50 border border-gray-100 rounded-xl px-4 py-3">
        <input type="checkbox" data-action="shop-toggle" data-id="${s.id}" ${s.done ? 'checked' : ''} class="w-5 h-5 accent-orange-500 cursor-pointer" aria-label="تم شراء ${esc(s.name)}">
        <span class="flex-grow ${s.done ? 'line-through text-gray-400' : 'font-semibold'}">${esc(s.name)}</span>
        <button data-action="shop-del" data-id="${s.id}" class="no-print text-gray-400 hover:text-red-500" aria-label="حذف">✕</button></li>`).join('')
    : '<li class="text-center text-gray-400 py-8">القائمة فارغة 🎉</li>';
  updateBadge();
}

/* ---------- خطة الأسبوع ---------- */
function renderPlanner() {
  if (!state.favorites.length) {
    $('planner-grid').innerHTML = `<div class="text-center text-gray-400 py-10">لا توجد وصفات مفضلة لإضافتها للخطة. ابحث عن وصفات واضغط ❤️ أولاً.</div>`;
    return;
  }
  const opts = (sel) => `<option value="">— لا شيء —</option>` +
    state.favorites.map((f) => `<option value="${esc(f.id)}" ${f.id === sel ? 'selected' : ''}>${esc(f.name)}</option>`).join('');
  $('planner-grid').innerHTML = DAYS.map((d) => `<div class="border border-gray-100 rounded-2xl p-3">
      <h3 class="font-black text-primary mb-2">${d}</h3>
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
      ${MEALS.map((m) => `<label class="text-xs font-bold text-gray-500">${m}
        <select data-plan-day="${d}" data-plan-meal="${m}" class="mt-1 w-full border border-gray-200 rounded-lg px-2 py-1.5 text-sm bg-white font-medium text-gray-800">${opts(state.plan[d]?.[m])}</select></label>`).join('')}
      </div></div>`).join('');
}
function planShopping() {
  const ids = new Set();
  Object.values(state.plan).forEach((day) => Object.values(day || {}).forEach((id) => id && ids.add(id)));
  const names = [];
  ids.forEach((id) => { const r = state.favorites.find((f) => f.id === id); if (r) names.push(...missingOf(r, false)); });
  if (!ids.size) { toast('الخطة فارغة'); return; }
  const n = addShopping(names);
  toast(n ? `أُضيف ${n} غرض للقائمة` : 'لا نواقص جديدة');
}

/* ---------- المؤقتات ---------- */
const timers = new Map();
function beep() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)(); const o = ctx.createOscillator();
    o.connect(ctx.destination); o.frequency.value = 880; o.start(); setTimeout(() => { o.stop(); ctx.close(); }, 600);
  } catch { /* بدون صوت */ }
}
function startTimer(btn, mins) {
  if (timers.has(btn)) { clearInterval(timers.get(btn)); timers.delete(btn); btn.textContent = `⏱ ${mins} د`; return; }
  let left = mins * 60;
  const tick = () => {
    if (!btn.isConnected) { clearInterval(timers.get(btn)); timers.delete(btn); return; }
    if (left <= 0) {
      clearInterval(timers.get(btn)); timers.delete(btn); btn.textContent = `⏱ ${mins} د`;
      toast('⏰ انتهى الوقت!'); beep(); try { navigator.vibrate?.([300, 150, 300]); } catch { /* */ } return;
    }
    btn.textContent = `⏳ ${String(Math.floor(left / 60)).padStart(2, '0')}:${String(left % 60).padStart(2, '0')}`; left--;
  };
  timers.set(btn, setInterval(tick, 1000)); tick();
}

/* ---------- الأحداث ---------- */
function bind() {
  document.querySelectorAll('.tab-btn').forEach((b) => b.addEventListener('click', () => switchTab(b.dataset.tab)));
  document.querySelectorAll('.meal-btn').forEach((b) => b.addEventListener('click', () => setMealType(b.dataset.meal)));

  const enter = (id, fn) => $(id).addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.isComposing) { e.preventDefault(); fn(); } });
  const addIng = () => { const i = $('ingredient-input'); if (addUnique(state.ingredients, i.value)) { save('ingredients'); renderIngredients(); refreshCards(); } else if (i.value.trim()) toast('المكون موجود مسبقاً'); i.value = ''; i.focus(); };
  const addPan = () => { const i = $('pantry-input'); if (addUnique(state.pantry, i.value)) { save('pantry'); renderPantry(); } else if (i.value.trim()) toast('موجود مسبقاً'); i.value = ''; i.focus(); };
  const addShop = () => { const i = $('shop-input'); if (i.value.trim() && !addShopping([i.value])) toast('موجود مسبقاً'); i.value = ''; i.focus(); };
  $('add-ingredient').onclick = addIng; enter('ingredient-input', addIng);
  $('add-pantry').onclick = addPan; enter('pantry-input', addPan);
  $('add-shop').onclick = addShop; enter('shop-input', addShop);

  $('clear-ingredients').onclick = () => { state.ingredients = []; save('ingredients'); renderIngredients(); refreshCards(); };
  $('pantry-clear').onclick = () => { if (confirm('مسح كل مواد المخزن؟')) { state.pantry = []; save('pantry'); renderPantry(); } };
  $('pantry-reset').onclick = () => { state.pantry = [...DEFAULT_PANTRY]; save('pantry'); renderPantry(); };
  $('generate-btn').onclick = fetchOnlineRecipes;
  $('plan-shop').onclick = planShopping;
  $('plan-print').onclick = () => window.print();
  $('plan-clear').onclick = () => { if (confirm('مسح خطة الأسبوع؟')) { state.plan = {}; save('plan'); renderPlanner(); } };
  $('shop-clear').onclick = () => { if (state.shopping.length && confirm('مسح كل القائمة؟')) { state.shopping = []; save('shopping'); renderShopping(); } };
  $('shop-clear-done').onclick = () => { state.shopping = state.shopping.filter((s) => !s.done); save('shopping'); renderShopping(); };
  $('shop-copy').onclick = async () => {
    const text = state.shopping.filter((s) => !s.done).map((s) => '• ' + s.name).join('\n');
    if (!text) return toast('لا يوجد ما يُنسخ');
    try { await navigator.clipboard.writeText(text); toast('تم نسخ القائمة'); } catch { toast('تعذّر النسخ'); }
  };

  $('planner-grid').addEventListener('change', (e) => {
    const s = e.target.closest('select[data-plan-day]'); if (!s) return;
    const d = s.dataset.planDay, m = s.dataset.planMeal;
    state.plan[d] = state.plan[d] || {};
    if (s.value) state.plan[d][m] = s.value; else delete state.plan[d][m];
    save('plan');
  });

  document.addEventListener('click', (e) => {
    const el = e.target.closest('[data-action]'); if (!el) return;
    const { action, id, i } = el.dataset;
    switch (action) {
      case 'del-ingredient': state.ingredients.splice(+i, 1); save('ingredients'); renderIngredients(); refreshCards(); break;
      case 'del-pantry': state.pantry.splice(+i, 1); save('pantry'); renderPantry(); break;
      case 'fav': toggleFav(id); break;
      case 'shop-missing': { const r = findRecipe(id); if (r) { const n = addShopping(missingOf(r)); toast(n ? `أُضيف ${n} غرض للقائمة` : 'موجودة مسبقاً في القائمة'); } break; }
      case 'shop-toggle': { const s = state.shopping.find((x) => x.id === id); if (s) { s.done = el.checked; save('shopping'); renderShopping(); } break; }
      case 'shop-del': state.shopping = state.shopping.filter((x) => x.id !== id); save('shopping'); renderShopping(); break;
      case 'timer': startTimer(el, +el.dataset.min); break;
      case 'retry': fetchOnlineRecipes(); break;
    }
  });
}

/* ---------- تشغيل ---------- */
function init() {
  if (!MEALS.includes(state.mealType)) state.mealType = 'غداء';
  ['ingredients', 'pantry', 'favorites', 'shopping'].forEach((k) => { if (!Array.isArray(state[k])) state[k] = []; });
  if (!state.plan || typeof state.plan !== 'object' || Array.isArray(state.plan)) state.plan = {};
  bind(); setMealType(state.mealType); renderIngredients(); renderPantry(); updateBadge();
}
init();
